﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testb
{
    class Program
    {
        static void Main(string[] args)
        {

            int m = 0;
            int n = 0;

            Console.WriteLine("Введите параметр М");
            m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите параметр N");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("=============");

            int[,] numbers = new int[m, n];
            int sum = 0;

            Random ran = new Random();

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    numbers[i, j] = ran.Next(15);
                    Console.Write("{0}\t", numbers[i, j]);
                }
                Console.WriteLine();
            }


            Console.WriteLine("\nСумма нечетных элементов: ");
            foreach (int i in numbers)
            {
                if ((i % 2) != 0)
                {
                    sum += i;
                }
            }
            Console.WriteLine(sum);
            Console.WriteLine();

            Console.WriteLine("Сортировка");
            for (int i = 0; i < m; i++)
            {
                for (int j = n - 1; j > 0; j--)
                {

                    for (int k = 0; k < j; k++)
                    {
                        if (numbers[i, k] > numbers[i, k + 1])
                        {
                            int temp = numbers[i, k];
                            numbers[i, k] = numbers[i, k + 1];
                            numbers[i, k + 1] = temp;
                        }
                    }
                    Console.WriteLine();
                }
            }

                

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.WriteLine("{0}\t", numbers[i, j]);
                }
                Console.WriteLine();
            }

                Console.ReadLine();

            }
        }
    }

