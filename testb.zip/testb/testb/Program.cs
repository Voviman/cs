﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testb
{
    class Program
    {
        static void Main(string[] args)
        {

            int m = 0;
            int n = 0;

            Console.WriteLine("Write M");
            m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Write N");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("=============");

            int[,] numbers = new int[m, n];
            int[] temp = new int[n];
            int sum = 0;

            Random ran = new Random();

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    numbers[i, j] = ran.Next(15);
                    Console.Write("{0}\t", numbers[i, j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("\nСортировка по строкам: ");
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                    temp[j] = numbers[i, j];
                Array.Sort(temp);
                for (int k = 0; k < n; k++)
                {
                    numbers[i, k] = temp[k];
                    Console.Write("{0}\t", numbers[i, k]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("\nСортировка по столбцам: ");
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                    temp[j] = numbers[j, i];
                Array.Sort(temp);
                for (int k = 0; k < n; k++)
                    numbers[k, i] = temp[k];
            }

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                    Console.Write("{0}\t", numbers[i, j]);
                Console.WriteLine();
            }

            Console.WriteLine("\nСумма нечетных элементов: ");
            foreach (int i in numbers)
            {
                if ((i % 2) != 0){
                    sum += i;
                }
            }
            Console.WriteLine(sum);
            Console.WriteLine();

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(0); j++)
                {
                    for (int k1 = 0; k1 < numbers.GetLength(1); k1++)
                    {
                        if (numbers[i, j] == numbers[i, k1]){
                            Console.WriteLine("Повторяющиеся элементы " + " " + numbers[i, j] + " " +  numbers[i, k1]);
                        }
                           
                        
                    }
                }
            }


            Console.ReadLine();

        }
    }
}
