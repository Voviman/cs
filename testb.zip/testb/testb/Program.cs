﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testb
{
    class Program
    {
        static void Main(string[] args)
        {

            int m = 0;
            int n = 0;

            Console.WriteLine("Write M");
            m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Write N");
            n = Convert.ToInt32(Console.ReadLine());

            int[,] numbers = new int[m, n];

            Random ran = new Random();

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    numbers[i, j] = ran.Next(15);
                    Console.WriteLine(numbers[i, j]);
                }
                Console.WriteLine();
            }

            Console.ReadLine();

        }
    }
}
